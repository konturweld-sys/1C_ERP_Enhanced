Metadata integrity patch for 1C extension Integration.
Branch: main
Contains Configuration.xml, ConfigDumpInfo.xml and four corrected metadata XML descriptions.
This is a patch set, not a complete source dump of the extension.
